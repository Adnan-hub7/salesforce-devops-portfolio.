# Example Git Branching Strategy

> A generic sample; align it with the team's actual release model.

- `main`: protected branch representing the approved baseline.
- `develop`: integration branch for upcoming work.
- `feature/<work-item>`: isolated development branch.
- `release/<version>`: stabilization and release preparation.
- `hotfix/<work-item>`: urgent production correction.

## Example flow

1. Create a feature branch from `develop`.
2. Commit focused changes with meaningful messages.
3. Open a pull request and complete review.
4. Run validation and automated checks.
5. Merge according to repository policy.
6. Promote the approved release branch through environments.
7. Tag the release and retain deployment evidence.

Resolve conflicts carefully, especially where multiple branches modify the same Salesforce metadata files.

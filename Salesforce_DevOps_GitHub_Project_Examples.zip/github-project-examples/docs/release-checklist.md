# Example Salesforce Release Checklist

> Sample checklist for practice and adaptation. Not an assertion about a specific employer release.

## Before release
- [ ] Confirm approved work items and deployment scope.
- [ ] Confirm source branch and target environment.
- [ ] Review metadata dependencies and destructive changes.
- [ ] Confirm test level and Apex test results.
- [ ] Check secret variables and service connections.
- [ ] Complete validation-only deployment.
- [ ] Obtain required approvals.
- [ ] Prepare communication and recovery plan.

## During release
- [ ] Record commit / tag / release identifier.
- [ ] Deploy the approved metadata package.
- [ ] Capture deployment ID and logs.
- [ ] Monitor errors and complete agreed smoke checks.

## After release
- [ ] Confirm business and technical validation.
- [ ] Communicate release outcome.
- [ ] Record defects, exceptions and follow-up actions.
- [ ] Update release documentation.

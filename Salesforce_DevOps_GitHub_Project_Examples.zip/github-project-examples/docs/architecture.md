# Reference Salesforce CI/CD Architecture

> Educational reference only. This is not a diagram of a verified production implementation.

```mermaid
flowchart LR
    A[Developer: VS Code / SFDX] --> B[Git feature branch]
    B --> C[Pull request and review]
    C --> D[CI: Azure Pipelines / Jenkins / GitHub Actions]
    D --> E[Static checks and Apex tests]
    E --> F[Validation-only deployment]
    F --> G[Approval gate]
    G --> H[Sandbox / UAT deployment]
    H --> I[Production release approval]
    I --> J[Production deployment]
    J --> K[Post-deployment checks and release record]
```

## Typical controls

1. Use pull requests and peer review before merging.
2. Store credentials in secret variables or a secure credential store.
3. Run metadata validation and Apex tests before deployment.
4. Require environment approvals for higher environments.
5. Record deployment output, commit ID, package scope and approver.
6. Prepare and document a recovery approach before production changes.

Copado and Gearset can provide Salesforce release orchestration and deployment capabilities. The exact implementation depends on the organization's configuration and governance.

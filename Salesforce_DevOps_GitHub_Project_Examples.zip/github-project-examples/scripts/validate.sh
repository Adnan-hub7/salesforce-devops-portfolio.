#!/usr/bin/env bash
# Illustrative validation-only deployment. Authenticate to the target sandbox first.
set -euo pipefail
TARGET_ORG="${1:-}"
if [[ -z "$TARGET_ORG" ]]; then
  echo "Usage: $0 <target-org-alias>"
  exit 2
fi
sf project deploy validate \
  --manifest manifest/package.xml \
  --target-org "$TARGET_ORG" \
  --test-level RunLocalTests \
  --wait 60

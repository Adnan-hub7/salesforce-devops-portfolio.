#!/usr/bin/env bash
# Illustrative deployment script. Use a sandbox first and review the manifest.
set -euo pipefail
TARGET_ORG="${1:-}"
if [[ -z "$TARGET_ORG" ]]; then
  echo "Usage: $0 <target-org-alias>"
  exit 2
fi
sf project deploy start \
  --manifest manifest/package.xml \
  --target-org "$TARGET_ORG" \
  --test-level RunLocalTests \
  --wait 60

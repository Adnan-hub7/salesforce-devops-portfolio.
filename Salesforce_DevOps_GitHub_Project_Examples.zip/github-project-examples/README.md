# Salesforce DevOps Portfolio Examples

**Owner:** Mohammed Adnan Qasmi  
**Purpose:** Demonstration repository to accompany a Salesforce DevOps Engineer portfolio.

> **Important:** All files in this repository are illustrative learning examples. They are not production pipelines, not employer-owned code, and do not prove that these exact configurations were used in a live environment. Review, adapt and test them in a Salesforce Developer Edition org or sandbox before use.

## Contents

- `azure-pipelines.yml`: sample Azure Pipelines validation workflow.
- `.github/workflows/salesforce-validation.yml`: sample GitHub Actions validation workflow.
- `Jenkinsfile`: sample Jenkins pipeline stages.
- `scripts/validate.sh`: Salesforce CLI validation example.
- `scripts/deploy.sh`: Salesforce CLI deployment example.
- `docs/architecture.md`: reference CI/CD architecture.
- `docs/release-checklist.md`: example release checklist.
- `docs/branching-strategy.md`: sample Git branching approach.

## Prerequisites

- Salesforce CLI (`sf`) installed on the runner.
- A Salesforce sandbox or Developer Edition org.
- A JWT or other approved authentication method configured securely.
- Environment-specific secrets configured in the CI platform.
- Salesforce DX project structure and `sfdx-project.json`.

## Run locally

```bash
chmod +x scripts/*.sh
./scripts/validate.sh my-sandbox
```

For deployment, inspect `scripts/deploy.sh`, confirm the target org and metadata scope, then run it only against a non-production sandbox first.

## Portfolio usage

You may fork this repository, update the documentation with your own verified practice work, and link it from your portfolio. Do not add passwords, private keys, access tokens, customer metadata or employer confidential information.
